import { configureStore } from '@reduxjs/toolkit';
import { authReducer } from './auth/slice';
import { todoReducer } from './todos/slice';
import { filtersReducer } from './filter/slice';

export const store = configureStore({
  reducer: {
    auth: authReducer,
    todos: todoReducer,
    filter: filtersReducer,
  },
});
