import { SignUpForm } from 'components/SignUpForm/SignUpForm';
export const SignUp = () => {
  return <SignUpForm />;
};
