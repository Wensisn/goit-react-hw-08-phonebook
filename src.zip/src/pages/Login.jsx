import { LoginForm } from 'components/LoginForm/LoginForm';

export const Login = () => {
  return <LoginForm />;
};
