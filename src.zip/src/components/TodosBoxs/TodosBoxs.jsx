// import { TodosForm } from '../TodosForm/TodosForm';
// import { TodosList } from '../TodosList/TodosList';
// import { Filter } from '../Filter/Filter';
// export const TodosBoxs = () => {
//   return (
//     <div>
//       <TodosForm />
//       <TodosList />
//       <Filter />
//     </div>
//   );
// };
