import styled from 'styled-components';

export const Boks = styled.div`
  display: flex;
  justify-content: center;
`;

export const Text = styled.h2`
  font-size: 20px;
  display: flex;
  justify-content: center;
`;

export const Label = styled.label``;

export const Input = styled.input``;
